// +build autobahn

package main

import "testing"

func TestCallMain(t *testing.T) {
	main()
}
